<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Redirecting</title>
  </head>
  <body onload="redirect()">
	<h1 style="text-align: center; padding-top: 50px; display: block;">Redirecting...</h1>
	<script>
	  function redirect() {
		setTimeout(function(){ 
				window.location.replace("https://geekprank.com/?err=404");
			}
			, 100);	
		}
	</script>
  </body>
</html>